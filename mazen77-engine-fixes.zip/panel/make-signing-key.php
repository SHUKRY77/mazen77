<?php
declare(strict_types=1);
// تشغيل مرة واحدة من SSH:  php make-signing-key.php
// ينشئ data/server-signing.key (مفتاح توقيع اللوحة) ويطبع المفتاح العام
// الذي يجب وضعه في SERVER_SIGNING_PUBLIC_B64 داخل SecureApi.java.
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
$dir = __DIR__ . '/data';
if (!is_dir($dir)) mkdir($dir, 0770, true);
$file = $dir . '/server-signing.key';
if (is_file($file)) {
    $key = openssl_pkey_get_private(file_get_contents($file));
    echo "المفتاح موجود مسبقاً، لن أستبدله.\n";
} else {
    $key = openssl_pkey_new(['private_key_type' => OPENSSL_KEYTYPE_EC, 'curve_name' => 'prime256v1']);
    openssl_pkey_export($key, $pem);
    file_put_contents($file, $pem);
    chmod($file, 0600);
    echo "تم إنشاء المفتاح.\n";
}
$d = openssl_pkey_get_details($key);
$der = base64_decode(preg_replace('/-----(BEGIN|END) PUBLIC KEY-----|\s/', '', $d['key']));
echo "SERVER_SIGNING_PUBLIC_B64 = " . base64_encode($der) . "\n";
