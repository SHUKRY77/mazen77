# JSch يحمّل خوارزميات التشفير وتبادل المفاتيح بـ reflection (Class.forName).
# بدون هذه القواعد يحذفها أو يعيد تسميتها R8 (التصغير مفعّل حتى في debug)
# فيفشل اتصال SSH دائماً مع "Algorithm negotiation fail" أو ClassNotFoundException.
-keep class com.jcraft.jsch.** { *; }
-keepclassmembers class com.jcraft.jsch.** { *; }
-dontwarn com.jcraft.jsch.**
-dontwarn org.ietf.jgss.**
-dontwarn org.apache.logging.log4j.**
-dontwarn org.slf4j.**
-dontwarn com.sun.jna.**
-dontwarn javax.naming.**
-dontwarn org.bouncycastle.**
